
function getUserID() {
  return localStorage.getItem("userID");
}

function filterMyListings() {
  const userID = getUserID();
  const listings = JSON.parse(localStorage.getItem("approvedListings") || "[]");
  const myListings = listings.filter(item => item.ownerID === userID);
  const container = document.getElementById("market");
  container.innerHTML = "";
  myListings.forEach(item => {
    const div = document.createElement("div");
    div.className = "listing";
    div.innerHTML = `<h4>${item.title} (${item.id})</h4>
      <p>${item.description}</p>
      <p>From: ${item.country}</p>
      <p>Price: £${item.price}</p>`;
    container.appendChild(div);
  });
}

function attachOwnerToListing(listing) {
  listing.ownerID = getUserID();
  return listing;
}
