if (!localStorage.getItem("userNickname")) {
    window.location.href = "welcome.html";
}