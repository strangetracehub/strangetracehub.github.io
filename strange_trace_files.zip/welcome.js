document.getElementById("anonLoginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const nickname = document.getElementById("nickname").value.trim();
    if (nickname.length > 0) {
        localStorage.setItem("userNickname", nickname);
        window.location.href = "browse.html";
    }
});