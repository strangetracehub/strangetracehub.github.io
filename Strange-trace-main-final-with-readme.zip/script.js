
  const modal = document.getElementById("buyModal");
  const buyButtons = document.querySelectorAll(".cta-button");

  buyButtons.forEach(btn => {
    if (btn.textContent.includes("Buy Now")) {
      btn.addEventListener("click", function(e) {
        e.preventDefault();
        modal.style.display = "flex";
      });
    }
  });

  function closeModal() {
    modal.style.display = "none";
  }

  function confirmBuy() {
    alert("Purchase confirmed! (This is a demo.)");
    closeModal();
  }
