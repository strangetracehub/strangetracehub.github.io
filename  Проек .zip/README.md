
# Strange Trace

**Strange Trace** is an anonymous marketplace for selling and buying used intimate wear.

---

## Project Structure

```
strange_trace_full_project/
├── backend/         # Server-side code (Flask/Node/etc.)
└── frontend/
    └── index.html   # Main user-facing interface
```

---

## Local Setup

### Python Backend (Flask/FastAPI)

If the backend contains `requirements.txt`:

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

To run the server:

**Flask**
```bash
export FLASK_APP=app.py
flask run
```

**FastAPI**
```bash
uvicorn main:app --reload
```

### Node.js Backend

If the backend contains `package.json`:

```bash
cd backend
npm install
npm start
```

---

## Access the Site

- Open `frontend/index.html` in your browser for the static interface.
- Or access via `http://localhost:5000` (Flask) or `http://localhost:3000` (Node).

---

## Deployment

### Python (Render)

1. Push your repo to GitHub.
2. Go to [Render.com](https://render.com) and create a new Web Service.
3. Use `gunicorn app:app` as start command.
4. Ensure `requirements.txt` and `Procfile` are present.

### Node.js (Vercel/Render)

1. Push to GitHub.
2. Vercel automatically builds based on `package.json`.
3. On Render, create Web Service, specify `npm start`.

---

## Notes

- Respect local laws and platform rules for content and anonymity.
- This project is a prototype and not production-ready without moderation, payments, and user controls.
